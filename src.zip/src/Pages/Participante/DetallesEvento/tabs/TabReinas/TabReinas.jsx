
const TabReinas=()=>{
    return(
        <>Imagenes de las Reinas</>
    )
}
export default TabReinas