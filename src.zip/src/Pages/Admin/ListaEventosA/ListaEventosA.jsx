import TablaEventos from "../../../Components/TablaEventos/TablaEventos"
const ListaEventosA=()=>{
    return(<>
        <h1>Lista de Eventos </h1>
        <TablaEventos/>
    </>)
}

export default ListaEventosA