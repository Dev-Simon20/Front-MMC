const EventosPasados=()=>{
    return(<>
        <h1>Lista de Eventos Pasados</h1>
    </>)
}

export default EventosPasados