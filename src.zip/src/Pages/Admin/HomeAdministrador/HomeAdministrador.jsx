import { Link, Outlet } from "react-router-dom"

const HomeAdministrador=()=>{
   
     return(<div>
        <h1>Se listara los eventos activos</h1>
     </div>)
}

export default HomeAdministrador