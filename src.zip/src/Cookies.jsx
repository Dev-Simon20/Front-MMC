// En un archivo centralizado, por ejemplo, cookies.js
import Cookies from 'js-cookie';
export default Cookies;