import './FootReg.css'

const FootReg=()=>{
    return(<div className='footte'>
        <p>¿Vas a realizár un concurso de marinera?</p>
        <p>Utiliza esta aplicación de registro de participantes totalmente<span className='gra'>GRATIS</span></p> 
        <p>separa una reunión al <span className='numberJ'>+51 980785754</span></p>
        <p>© 2024 <span className='min'>MImarinera.com</span>. Todos los derechos reservados.</p>
    </div>)
}

export default FootReg